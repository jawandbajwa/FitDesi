// ============================================================
// FITDESI — RECIPES DATABASE
// ============================================================
// HOW IT WORKS:
// - Each recipe uses ingredient names + actual grams used
// - getMacros() calculates macros automatically from ingredients.js
// - totalMacros() sums all ingredients in a recipe
// - defaultServing = the portion this recipe makes
// ============================================================

const { getMacros, findIngredient } = require('./ingredients');

// ─── RECIPE BUILDER ──────────────────────────────────────────
function buildRecipe(recipe) {
  const computedIngredients = recipe.ingredients.map(item => {
    const macros = getMacros(item.name, item.grams);
    return {
      ...item,
      macros,
    };
  });

  const totals = computedIngredients.reduce(
    (acc, item) => {
      if (!item.macros) return acc;
      acc.protein += item.macros.protein;
      acc.carbs += item.macros.carbs;
      acc.fat += item.macros.fat;
      acc.fiber += item.macros.fiber;
      acc.calories += item.macros.calories;
      return acc;
    },
    { protein: 0, carbs: 0, fat: 0, fiber: 0, calories: 0 }
  );

  return {
    ...recipe,
    ingredients: computedIngredients,
    totalMacros: {
      protein: Math.round(totals.protein * 10) / 10,
      carbs: Math.round(totals.carbs * 10) / 10,
      fat: Math.round(totals.fat * 10) / 10,
      fiber: Math.round(totals.fiber * 10) / 10,
      calories: Math.round(totals.calories),
    }
  };
}

// ============================================================
// RECIPES
// Source: Varinder Ghuman diet, Biki Singh meal plan,
//         Archana's Kitchen, Tarla Dalal, verified Indian
//         fitness nutrition sources — no eggs, no meat
// ============================================================

const rawRecipes = [

  // ─────────────────────────────────────────────
  // BREAKFAST
  // ─────────────────────────────────────────────

  {
    name: "Paneer Bhurji",
    category: "breakfast",
    servingSize: "1 plate",
    prepTime: "15 min",
    source: "Varinder Ghuman diet staple",
    ingredients: [
      { name: "Paneer (full fat)", grams: 150 },
      { name: "Onion", grams: 60 },
      { name: "Tomato", grams: 80 },
      { name: "Capsicum / Bell Pepper", grams: 50 },
      { name: "Ghee", grams: 5 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Red Chilli Powder", grams: 2 },
      { name: "Garam Masala", grams: 2 },
      { name: "Salt", grams: 3 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
    ]
  },

  {
    name: "Moong Dal Chilla",
    category: "breakfast",
    servingSize: "2 chillas",
    prepTime: "20 min (+ 4hr soak)",
    source: "High protein Indian breakfast — Archana's Kitchen",
    ingredients: [
      { name: "Moong Dal (Yellow, split)", grams: 80 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Green Chilli", grams: 5 },
      { name: "Onion", grams: 40 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Salt", grams: 2 },
      { name: "Sunflower Oil", grams: 5 },
    ]
  },

  {
    name: "Overnight Oats (High Protein)",
    category: "breakfast",
    servingSize: "1 bowl",
    prepTime: "5 min (+ overnight)",
    source: "Adapted from Indian fitness nutrition guides",
    ingredients: [
      { name: "Oats (rolled)", grams: 60 },
      { name: "Curd / Dahi (full fat)", grams: 100 },
      { name: "Diesel NZ Whey Isolate", grams: 30 },
      { name: "Chia Seeds", grams: 10 },
      { name: "Banana (ripe)", grams: 80 },
      { name: "Almonds (Badam)", grams: 15 },
    ]
  },

  {
    name: "Besan Chilla (Chickpea Pancake)",
    category: "breakfast",
    servingSize: "2 chillas",
    prepTime: "15 min",
    source: "Tarla Dalal high protein breakfast",
    ingredients: [
      { name: "Besan (Chickpea Flour)", grams: 80 },
      { name: "Onion", grams: 50 },
      { name: "Tomato", grams: 50 },
      { name: "Capsicum / Bell Pepper", grams: 30 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Green Chilli", grams: 5 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Salt", grams: 2 },
      { name: "Sunflower Oil", grams: 5 },
    ]
  },

  {
    name: "Protein Smoothie (Post Workout)",
    category: "breakfast",
    servingSize: "1 glass (400ml)",
    prepTime: "5 min",
    source: "Adapted from Indian vegetarian bodybuilder diets",
    ingredients: [
      { name: "Diesel NZ Whey Isolate", grams: 30 },
      { name: "Milk (cow, full fat)", grams: 250 },
      { name: "Banana (ripe)", grams: 100 },
      { name: "Peanut Butter (natural)", grams: 20 },
      { name: "Chia Seeds", grams: 10 },
    ]
  },

  {
    name: "Quinoa Upma",
    category: "breakfast",
    servingSize: "1 bowl",
    prepTime: "20 min",
    source: "High protein alternative to suji upma",
    ingredients: [
      { name: "Quinoa (raw)", grams: 60 },
      { name: "Onion", grams: 60 },
      { name: "Tomato", grams: 60 },
      { name: "Peas (Matar, fresh)", grams: 40 },
      { name: "Carrot (Gajar)", grams: 40 },
      { name: "Mustard Oil", grams: 5 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Green Chilli", grams: 5 },
      { name: "Curry Leaves", grams: 3 },
      { name: "Salt", grams: 2 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
    ]
  },

  // ─────────────────────────────────────────────
  // LUNCH
  // ─────────────────────────────────────────────

  {
    name: "Dal Tadka",
    category: "lunch",
    servingSize: "1 bowl",
    prepTime: "30 min",
    source: "Varinder Ghuman staple — yellow dal",
    ingredients: [
      { name: "Toor Dal", grams: 60 },
      { name: "Onion", grams: 80 },
      { name: "Tomato", grams: 80 },
      { name: "Garlic (Lehsun)", grams: 10 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Ghee", grams: 10 },
      { name: "Cumin Seeds (Jeera)", grams: 3 },
      { name: "Turmeric Powder (Haldi)", grams: 2 },
      { name: "Red Chilli Powder", grams: 2 },
      { name: "Garam Masala", grams: 2 },
      { name: "Salt", grams: 3 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
    ]
  },

  {
    name: "Rajma Masala",
    category: "lunch",
    servingSize: "1 bowl",
    prepTime: "45 min (+ overnight soak)",
    source: "Biki Singh meal 3 — kidney beans with rice",
    ingredients: [
      { name: "Rajma (Kidney Beans)", grams: 80 },
      { name: "Onion", grams: 100 },
      { name: "Tomato", grams: 100 },
      { name: "Garlic (Lehsun)", grams: 10 },
      { name: "Ginger (Adrak)", grams: 8 },
      { name: "Mustard Oil", grams: 10 },
      { name: "Cumin Seeds (Jeera)", grams: 3 },
      { name: "Turmeric Powder (Haldi)", grams: 2 },
      { name: "Red Chilli Powder", grams: 3 },
      { name: "Garam Masala", grams: 3 },
      { name: "Salt", grams: 3 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
    ]
  },

  {
    name: "Chana Masala",
    category: "lunch",
    servingSize: "1 bowl",
    prepTime: "40 min",
    source: "Biki Singh meal 2 — boiled chickpeas",
    ingredients: [
      { name: "Kabuli Chana (Chickpeas)", grams: 80 },
      { name: "Onion", grams: 100 },
      { name: "Tomato", grams: 100 },
      { name: "Garlic (Lehsun)", grams: 10 },
      { name: "Ginger (Adrak)", grams: 8 },
      { name: "Sunflower Oil", grams: 10 },
      { name: "Cumin Seeds (Jeera)", grams: 3 },
      { name: "Turmeric Powder (Haldi)", grams: 2 },
      { name: "Red Chilli Powder", grams: 3 },
      { name: "Garam Masala", grams: 3 },
      { name: "Salt", grams: 3 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
    ]
  },

  {
    name: "Palak Paneer",
    category: "lunch",
    servingSize: "1 bowl",
    prepTime: "30 min",
    source: "Tarla Dalal high protein sabzi",
    ingredients: [
      { name: "Paneer (full fat)", grams: 100 },
      { name: "Spinach (Palak)", grams: 150 },
      { name: "Onion", grams: 80 },
      { name: "Tomato", grams: 60 },
      { name: "Garlic (Lehsun)", grams: 8 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Ghee", grams: 8 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Red Chilli Powder", grams: 2 },
      { name: "Garam Masala", grams: 2 },
      { name: "Salt", grams: 3 },
    ]
  },

  {
    name: "Soya Chunk Masala",
    category: "lunch",
    servingSize: "1 bowl",
    prepTime: "25 min",
    source: "Hiralal Dhillan diet — soya beans",
    ingredients: [
      { name: "Soya Chunks", grams: 50 },
      { name: "Onion", grams: 80 },
      { name: "Tomato", grams: 80 },
      { name: "Capsicum / Bell Pepper", grams: 50 },
      { name: "Garlic (Lehsun)", grams: 8 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Sunflower Oil", grams: 8 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 2 },
      { name: "Red Chilli Powder", grams: 2 },
      { name: "Garam Masala", grams: 2 },
      { name: "Salt", grams: 3 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
    ]
  },

  {
    name: "Dal Khichdi",
    category: "lunch",
    servingSize: "1 bowl",
    prepTime: "25 min",
    source: "Complete protein meal — dal + rice amino acids",
    ingredients: [
      { name: "Moong Dal (Yellow, split)", grams: 50 },
      { name: "Basmati Rice (raw)", grams: 40 },
      { name: "Ghee", grams: 5 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Carrot (Gajar)", grams: 40 },
      { name: "Peas (Matar, fresh)", grams: 40 },
      { name: "Salt", grams: 2 },
      { name: "Coriander Leaves (Dhania)", grams: 8 },
    ]
  },

  {
    name: "Basmati Rice (plain)",
    category: "lunch",
    servingSize: "1 katori cooked",
    prepTime: "15 min",
    source: "Biki Singh — rice with rajma or ghee",
    ingredients: [
      { name: "Basmati Rice (raw)", grams: 60 },
      { name: "Ghee", grams: 5 },
      { name: "Salt", grams: 1 },
    ]
  },

  {
    name: "Whole Wheat Roti",
    category: "lunch",
    servingSize: "2 rotis",
    prepTime: "15 min",
    source: "Varinder Ghuman staple — chapatti",
    ingredients: [
      { name: "Whole Wheat Flour (Atta)", grams: 60 },
      { name: "Ghee", grams: 5 },
      { name: "Salt", grams: 1 },
    ]
  },

  // ─────────────────────────────────────────────
  // DINNER
  // ─────────────────────────────────────────────

  {
    name: "Masoor Dal (Simple)",
    category: "dinner",
    servingSize: "1 bowl",
    prepTime: "20 min",
    source: "Everyday Indian dinner — fast cooking dal",
    ingredients: [
      { name: "Masoor Dal (Red Lentil)", grams: 60 },
      { name: "Onion", grams: 60 },
      { name: "Tomato", grams: 60 },
      { name: "Garlic (Lehsun)", grams: 8 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Ghee", grams: 8 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Red Chilli Powder", grams: 2 },
      { name: "Salt", grams: 2 },
      { name: "Coriander Leaves (Dhania)", grams: 8 },
    ]
  },

  {
    name: "Paneer Tikka (Grilled)",
    category: "dinner",
    servingSize: "1 plate (6 pieces)",
    prepTime: "30 min",
    source: "High protein low carb dinner",
    ingredients: [
      { name: "Paneer (full fat)", grams: 150 },
      { name: "Curd / Dahi (full fat)", grams: 60 },
      { name: "Capsicum / Bell Pepper", grams: 60 },
      { name: "Onion", grams: 60 },
      { name: "Tomato", grams: 60 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Garlic (Lehsun)", grams: 5 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Red Chilli Powder", grams: 3 },
      { name: "Garam Masala", grams: 2 },
      { name: "Sunflower Oil", grams: 5 },
      { name: "Salt", grams: 3 },
    ]
  },

  {
    name: "Tofu Tikka Masala",
    category: "dinner",
    servingSize: "1 bowl",
    prepTime: "30 min",
    source: "Vegan alternative — high protein, low fat",
    ingredients: [
      { name: "Tofu (extra firm)", grams: 150 },
      { name: "Onion", grams: 80 },
      { name: "Tomato", grams: 100 },
      { name: "Garlic (Lehsun)", grams: 8 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Sunflower Oil", grams: 8 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Red Chilli Powder", grams: 2 },
      { name: "Garam Masala", grams: 2 },
      { name: "Salt", grams: 3 },
      { name: "Coriander Leaves (Dhania)", grams: 10 },
    ]
  },

  {
    name: "Rajma Rice Bowl",
    category: "dinner",
    servingSize: "1 bowl",
    prepTime: "10 min (if pre-cooked)",
    source: "Biki Singh complete meal — rajma + rice + ghee",
    ingredients: [
      { name: "Rajma (Kidney Beans)", grams: 80 },
      { name: "Basmati Rice (raw)", grams: 60 },
      { name: "Onion", grams: 80 },
      { name: "Tomato", grams: 80 },
      { name: "Garlic (Lehsun)", grams: 8 },
      { name: "Ghee", grams: 8 },
      { name: "Cumin Seeds (Jeera)", grams: 2 },
      { name: "Turmeric Powder (Haldi)", grams: 1 },
      { name: "Garam Masala", grams: 2 },
      { name: "Salt", grams: 3 },
    ]
  },

  {
    name: "Panchmel Dal (Five Dal Mix)",
    category: "dinner",
    servingSize: "1 bowl",
    prepTime: "35 min",
    source: "Complete amino acid profile — all five dals",
    ingredients: [
      { name: "Toor Dal", grams: 20 },
      { name: "Moong Dal (Yellow, split)", grams: 15 },
      { name: "Masoor Dal (Red Lentil)", grams: 15 },
      { name: "Chana Dal", grams: 15 },
      { name: "Urad Dal", grams: 15 },
      { name: "Onion", grams: 80 },
      { name: "Tomato", grams: 80 },
      { name: "Garlic (Lehsun)", grams: 8 },
      { name: "Ginger (Adrak)", grams: 5 },
      { name: "Ghee", grams: 8 },
      { name: "Cumin Seeds (Jeera)", grams: 3 },
      { name: "Turmeric Powder (Haldi)", grams: 2 },
      { name: "Red Chilli Powder", grams: 2 },
      { name: "Garam Masala", grams: 2 },
      { name: "Salt", grams: 3 },
    ]
  },

  // ─────────────────────────────────────────────
  // SNACKS
  // ─────────────────────────────────────────────

  {
    name: "Roasted Chana (Sattu Drink)",
    category: "snack",
    servingSize: "1 glass",
    prepTime: "3 min",
    source: "Biki Singh between-meal snack — roasted chana",
    ingredients: [
      { name: "Sattu (Roasted Chana Flour)", grams: 40 },
      { name: "Jaggery (Gur)", grams: 10 },
    ]
  },

  {
    name: "Greek Yogurt with Nuts",
    category: "snack",
    servingSize: "1 bowl",
    prepTime: "2 min",
    source: "High protein snack — Tarla Dalal inspired",
    ingredients: [
      { name: "Greek Yogurt (full fat)", grams: 150 },
      { name: "Almonds (Badam)", grams: 15 },
      { name: "Walnuts (Akhrot)", grams: 10 },
      { name: "Flaxseeds (Alsi)", grams: 8 },
    ]
  },

  {
    name: "Peanut Butter Banana Toast",
    category: "snack",
    servingSize: "2 slices",
    prepTime: "5 min",
    source: "Pre-workout snack",
    ingredients: [
      { name: "Whole Wheat Flour (Atta)", grams: 60 },
      { name: "Peanut Butter (natural)", grams: 30 },
      { name: "Banana (ripe)", grams: 80 },
    ]
  },

  {
    name: "Sprouted Moong Salad",
    category: "snack",
    servingSize: "1 bowl",
    prepTime: "5 min",
    source: "Archana's Kitchen high protein salad",
    ingredients: [
      { name: "Whole Moong (Green Gram)", grams: 60 },
      { name: "Onion", grams: 40 },
      { name: "Tomato", grams: 40 },
      { name: "Cucumber (Kheera)", grams: 50 },
      { name: "Green Chilli", grams: 5 },
      { name: "Coriander Leaves (Dhania)", grams: 8 },
    ]
  },

  {
    name: "Protein Shake (Simple)",
    category: "snack",
    servingSize: "1 glass",
    prepTime: "2 min",
    source: "Post workout recovery",
    ingredients: [
      { name: "Diesel NZ Whey Isolate", grams: 30 },
      { name: "Milk (cow, full fat)", grams: 300 },
    ]
  },

  {
    name: "Mixed Nuts & Seeds",
    category: "snack",
    servingSize: "1 handful",
    prepTime: "0 min",
    source: "Varinder Ghuman — nuts as snack",
    ingredients: [
      { name: "Almonds (Badam)", grams: 15 },
      { name: "Cashews (Kaju)", grams: 10 },
      { name: "Pumpkin Seeds", grams: 10 },
      { name: "Dates (Khajoor, dry)", grams: 20 },
    ]
  },

];

// ─── BUILD ALL RECIPES ───────────────────────────────────────
const recipes = rawRecipes.map(buildRecipe);

// ─── UTILITY FUNCTIONS ───────────────────────────────────────

// Get all recipes by category
function getByCategory(category) {
  return recipes.filter(r => r.category === category);
}

// Print recipe summary to console
function printRecipe(recipe) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(`📋 ${recipe.name.toUpperCase()}`);
  console.log(`Category: ${recipe.category} | Serving: ${recipe.servingSize}`);
  console.log(`Source: ${recipe.source}`);
  console.log(`${'─'.repeat(60)}`);
  console.log('INGREDIENTS:');
  recipe.ingredients.forEach(item => {
    if (item.macros) {
      console.log(`  ${item.name.padEnd(30)} ${String(item.grams + 'g').padEnd(8)} → P:${item.macros.protein}g  C:${item.macros.carbs}g  F:${item.macros.fat}g  ${item.macros.calories}cal`);
    }
  });
  console.log(`${'─'.repeat(60)}`);
  const t = recipe.totalMacros;
  console.log(`TOTAL → Protein: ${t.protein}g | Carbs: ${t.carbs}g | Fat: ${t.fat}g | Fiber: ${t.fiber}g | Calories: ${t.calories}`);
}

// Print all recipes in a category
function printCategory(category) {
  const categoryRecipes = getByCategory(category);
  console.log(`\n${'#'.repeat(60)}`);
  console.log(`# ${category.toUpperCase()} RECIPES (${categoryRecipes.length} total)`);
  console.log(`${'#'.repeat(60)}`);
  categoryRecipes.forEach(printRecipe);
}

// Export for use in admin panel / Firebase import
module.exports = { recipes, getByCategory, printRecipe, printCategory };

// ─── RUN IF EXECUTED DIRECTLY ────────────────────────────────
// node recipes.js → prints all recipes with full macro breakdown
if (require.main === module) {
  console.log('\nFITDESI — COMPLETE RECIPE DATABASE WITH AUTO-CALCULATED MACROS');
  console.log('Source: IFCT 2017, Varinder Ghuman, Biki Singh, Archana\'s Kitchen');
  console.log(`Total recipes: ${recipes.length}`);

  ['breakfast', 'lunch', 'dinner', 'snack'].forEach(printCategory);

  console.log('\n\nQUICK SUMMARY TABLE:');
  console.log('Name'.padEnd(35) + 'Cat'.padEnd(12) + 'P'.padEnd(8) + 'C'.padEnd(8) + 'F'.padEnd(8) + 'Cal');
  console.log('─'.repeat(75));
  recipes.forEach(r => {
    const t = r.totalMacros;
    console.log(
      r.name.padEnd(35) +
      r.category.padEnd(12) +
      (t.protein + 'g').padEnd(8) +
      (t.carbs + 'g').padEnd(8) +
      (t.fat + 'g').padEnd(8) +
      t.calories
    );
  });
}
