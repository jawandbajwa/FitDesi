import {
    auth,
    onAuthStateChanged,
    getRecipes,
    saveDailyLog,
    getDailyLog
} from './firebase.js';

let currentUser = null;
let allRecipes = [];
let activeCategory = 'all';
let activeCuisine = 'indian';
let searchQuery = '';
let currentRecipe = null;
let selectedMeal = '';

// ─── EMOJI MAPPING ───────────────────────────────────────────
function getRecipeEmoji(name, category) {
    const n = name.toLowerCase();
    if (n.includes('paneer')) return '🧀';
    if (n.includes('dal') || n.includes('daal')) return '🍲';
    if (n.includes('rice') || n.includes('khichdi')) return '🍚';
    if (n.includes('roti') || n.includes('paratha') || n.includes('thepla')) return '🫓';
    if (n.includes('oat') || n.includes('porridge')) return '🥣';
    if (n.includes('pancake') || n.includes('chilla')) return '🥞';
    if (n.includes('smoothie') || n.includes('shake') || n.includes('lassi')) return '🥤';
    if (n.includes('salad') || n.includes('sprout')) return '🥗';
    if (n.includes('chana') || n.includes('chickpea') || n.includes('rajma') || n.includes('bean')) return '🫘';
    if (n.includes('soup') || n.includes('lentil')) return '🍜';
    if (n.includes('tofu')) return '🫕';
    if (n.includes('toast') || n.includes('bread') || n.includes('sandwich')) return '🍞';
    if (n.includes('wrap') || n.includes('burrito') || n.includes('taco')) return '🌯';
    if (n.includes('bowl')) return '🥗';
    if (n.includes('yogurt') || n.includes('curd') || n.includes('cottage')) return '🫙';
    if (n.includes('curry')) return '🍛';
    if (n.includes('pasta') || n.includes('bolognese')) return '🍝';
    if (n.includes('hummus')) return '🥙';
    if (n.includes('nut') || n.includes('almond') || n.includes('walnut')) return '🥜';
    if (n.includes('protein') || n.includes('whey')) return '💪';
    if (n.includes('avocado')) return '🥑';
    if (n.includes('stir fry')) return '🥘';
    if (n.includes('chili')) return '🌶️';
    const catEmojis = { breakfast: '🌅', lunch: '☀️', dinner: '🌙', snack: '🍎' };
    return catEmojis[category] || '🍛';
}

// ─── RENDER RECIPE LIST ──────────────────────────────────────
function renderRecipes() {
    const list = document.getElementById('recipeList');
    const empty = document.getElementById('emptyState');

    let filtered = allRecipes.filter(r => {
        const catMatch = activeCategory === 'all' || r.category === activeCategory;
        const searchMatch = r.name.toLowerCase().includes(searchQuery.toLowerCase());
        return catMatch && searchMatch;
    });

    if (filtered.length === 0) {
        list.innerHTML = '';
        empty.classList.remove('hidden');
        list.appendChild(empty);
        return;
    }

    empty.classList.add('hidden');
    list.innerHTML = filtered.map(r => `
        <div class="recipe-item" data-id="${r.id}">
            <div class="recipe-emoji">${getRecipeEmoji(r.name, r.category)}</div>
            <div class="recipe-content">
                <div class="recipe-name">${r.name}</div>
                <div class="recipe-macros">
                    <div class="recipe-macro">P <span>${r.protein}g</span></div>
                    <div class="recipe-macro">C <span>${r.carbs}g</span></div>
                    <div class="recipe-macro">F <span>${r.fat}g</span></div>
                    <div class="recipe-macro">Cal <span>${r.calories}</span></div>
                </div>
            </div>
            <div class="recipe-cat-tag">${r.category}</div>
            <div class="recipe-arrow">→</div>
        </div>
    `).join('');

    list.querySelectorAll('.recipe-item').forEach(el => {
        el.addEventListener('click', () => {
            const recipe = allRecipes.find(r => r.id === el.dataset.id);
            if (recipe) openDetail(recipe);
        });
    });
}

// ─── OPEN DETAIL ─────────────────────────────────────────────
function openDetail(recipe) {
    currentRecipe = recipe;
    document.getElementById('detailPanel').classList.remove('hidden');
    document.getElementById('detailIcon').textContent = getRecipeEmoji(recipe.name, recipe.category);
    document.getElementById('detailName').textContent = recipe.name;
    document.getElementById('detailMeta').textContent =
        `${recipe.category} · ${recipe.servingSize || '1 serving'} · ${recipe.prepTime || ''} · ${activeCuisine === 'canadian' ? '🇨🇦 Canadian' : '🇮🇳 Indian'}`;

    // Macro cards
    document.getElementById('detailMacros').innerHTML = `
        <div class="macro-card">
            <div class="macro-val">${recipe.protein}g</div>
            <div class="macro-lbl">Protein</div>
        </div>
        <div class="macro-card">
            <div class="macro-val">${recipe.carbs}g</div>
            <div class="macro-lbl">Carbs</div>
        </div>
        <div class="macro-card">
            <div class="macro-val">${recipe.fat}g</div>
            <div class="macro-lbl">Fat</div>
        </div>
        <div class="macro-card">
            <div class="macro-val">${recipe.calories}</div>
            <div class="macro-lbl">Cal</div>
        </div>
    `;

    // Ingredients
    const ingredients = recipe.ingredients || [];
    document.getElementById('detailIngredients').innerHTML = ingredients.length > 0
        ? ingredients.map(ing => `
            <div class="ingredient-row">
                <span class="ingredient-name">${ing.name}</span>
                <span class="ingredient-amount">${ing.amount}${ing.unit || 'g'}</span>
            </div>
        `).join('')
        : '<div style="color:rgba(255,255,255,0.2);font-size:12px;padding:8px 0">No ingredients listed</div>';

    // Instructions
    const instructions = recipe.instructions || [];
    const instructionsEl = document.getElementById('detailInstructions');
    const instructionsLabel = document.getElementById('instructionsLabel');

    if (instructions.length > 0) {
        instructionsLabel.style.display = 'block';
        instructionsEl.innerHTML = instructions.map((step, i) => `
            <div class="instruction-step">
                <div class="step-number">${i + 1}</div>
                <div class="step-text">${step}</div>
            </div>
        `).join('');
    } else {
        instructionsLabel.style.display = 'none';
        instructionsEl.innerHTML = '';
    }

    // Video
    const videoEl = document.getElementById('detailVideo');
    const videoLabel = document.getElementById('videoLabel');
    if (recipe.videoId) {
        videoLabel.style.display = 'block';
        videoEl.innerHTML = `<iframe src="https://www.youtube.com/embed/${recipe.videoId}?rel=0&modestbranding=1" allowfullscreen loading="lazy"></iframe>`;
    } else {
        videoLabel.style.display = 'none';
        videoEl.innerHTML = '';
    }

    window.scrollTo(0, 0);
}

// ─── MEAL SELECTOR ───────────────────────────────────────────
function openMealSelector(recipe) {
    selectedMeal = recipe.category === 'snack' ? 'snack' : recipe.category;
    document.getElementById('mealSelectorRecipeName').textContent = recipe.name;
    document.getElementById('mealSelectorModal').classList.add('open');
    document.querySelectorAll('.meal-sel-btn').forEach(btn => {
        btn.classList.toggle('selected', btn.dataset.meal === selectedMeal);
    });
}

async function addRecipeToMeal(meal) {
    if (!currentUser || !currentRecipe) return;
    const dateKey = new Date().toDateString();
    const log = await getDailyLog(currentUser.uid, dateKey);
    if (!log[meal]) log[meal] = [];
    log[meal].push({
        name:     currentRecipe.name,
        protein:  currentRecipe.protein  || 0,
        carbs:    currentRecipe.carbs    || 0,
        fat:      currentRecipe.fat      || 0,
        calories: currentRecipe.calories || 0
    });
    await saveDailyLog(currentUser.uid, dateKey, log);
    document.getElementById('mealSelectorModal').classList.remove('open');
    alert(`${currentRecipe.name} added to ${meal}! ✓`);
}

// ─── CUISINE SWITCHER ────────────────────────────────────────
document.querySelectorAll('.cuisine-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        document.querySelectorAll('.cuisine-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeCuisine = btn.dataset.cuisine;
        activeCategory = 'all';
        document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('.cat-btn[data-cat="all"]').classList.add('active');
        allRecipes = await getRecipes(activeCuisine);
        renderRecipes();
    });
});

// ─── CATEGORY FILTER ─────────────────────────────────────────
document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeCategory = btn.dataset.cat;
        renderRecipes();
    });
});

// ─── SEARCH ──────────────────────────────────────────────────
document.getElementById('recipeSearch').addEventListener('input', e => {
    searchQuery = e.target.value;
    renderRecipes();
});

// ─── DETAIL PANEL ────────────────────────────────────────────
document.getElementById('detailBack').addEventListener('click', () => {
    document.getElementById('detailPanel').classList.add('hidden');
    currentRecipe = null;
});

document.getElementById('addToMealBtn').addEventListener('click', () => {
    if (currentRecipe) openMealSelector(currentRecipe);
});

// ─── MEAL SELECTOR ───────────────────────────────────────────
document.getElementById('mealSelectorClose').addEventListener('click', () => {
    document.getElementById('mealSelectorModal').classList.remove('open');
});

document.querySelectorAll('.meal-sel-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.meal-sel-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        selectedMeal = btn.dataset.meal;
    });
});

document.getElementById('confirmAddMeal').addEventListener('click', async () => {
    if (selectedMeal) await addRecipeToMeal(selectedMeal);
});

// ─── INIT ────────────────────────────────────────────────────
document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-US', {
    weekday: 'short', day: 'numeric', month: 'short'
});

onAuthStateChanged(auth, async (user) => {
    if (!user) {
        window.location.href = 'login.html';
        return;
    }
    currentUser = user;
    allRecipes = await getRecipes(activeCuisine);
    renderRecipes();
});
