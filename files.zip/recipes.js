// ============================================================
// FITDESI — INDIAN RECIPES DATABASE
// ============================================================
// No eggs, no meat, pure vegetarian
// Sources: Varinder Ghuman, Biki Singh, Archana's Kitchen,
//          Tarla Dalal, Hebbars Kitchen
// All macros auto-calculated from ingredients.js
// ============================================================

const { getMacros } = require('./ingredients');

function buildRecipe(recipe) {
  const computedIngredients = recipe.ingredients.map(item => ({
    ...item,
    macros: getMacros(item.name, item.grams),
  }));
  const totals = computedIngredients.reduce(
    (acc, item) => {
      if (!item.macros) return acc;
      acc.protein  += item.macros.protein;
      acc.carbs    += item.macros.carbs;
      acc.fat      += item.macros.fat;
      acc.fiber    += item.macros.fiber;
      acc.calories += item.macros.calories;
      return acc;
    },
    { protein: 0, carbs: 0, fat: 0, fiber: 0, calories: 0 }
  );
  return {
    ...recipe,
    ingredients: computedIngredients,
    totalMacros: {
      protein:  Math.round(totals.protein  * 10) / 10,
      carbs:    Math.round(totals.carbs    * 10) / 10,
      fat:      Math.round(totals.fat      * 10) / 10,
      fiber:    Math.round(totals.fiber    * 10) / 10,
      calories: Math.round(totals.calories),
    }
  };
}

const rawRecipes = [

  // ══════════════════════════════════════════════
  // BREAKFAST
  // ══════════════════════════════════════════════

  {
    name: 'Paneer Bhurji',
    category: 'breakfast',
    servingSize: '1 plate',
    prepTime: '15 min',
    source: 'Varinder Ghuman diet staple',
    videoId: 'qWbHSOplcvY',
    ingredients: [
      { name: 'Paneer (full fat)',           grams: 150 },
      { name: 'Onion',                       grams: 60  },
      { name: 'Tomato',                      grams: 80  },
      { name: 'Capsicum / Bell Pepper',      grams: 50  },
      { name: 'Ghee',                        grams: 5   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Moong Dal Chilla',
    category: 'breakfast',
    servingSize: '2 chillas',
    prepTime: '20 min + 4hr soak',
    source: "Archana's Kitchen",
    videoId: 'K5VB9OpSgOI',
    ingredients: [
      { name: 'Moong Dal (Yellow, split)',   grams: 80  },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Green Chilli',               grams: 5   },
      { name: 'Onion',                       grams: 40  },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Salt',                        grams: 2   },
      { name: 'Sunflower Oil',              grams: 5   },
    ]
  },

  {
    name: 'Besan Chilla',
    category: 'breakfast',
    servingSize: '2 chillas',
    prepTime: '15 min',
    source: 'Tarla Dalal high protein breakfast',
    videoId: 'xQBBLJiNgJI',
    ingredients: [
      { name: 'Besan (Chickpea Flour)',      grams: 80  },
      { name: 'Onion',                       grams: 50  },
      { name: 'Tomato',                      grams: 50  },
      { name: 'Capsicum / Bell Pepper',      grams: 30  },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Green Chilli',               grams: 5   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Salt',                        grams: 2   },
      { name: 'Sunflower Oil',              grams: 5   },
    ]
  },

  {
    name: 'Overnight Oats (High Protein)',
    category: 'breakfast',
    servingSize: '1 bowl',
    prepTime: '5 min + overnight',
    source: 'Indian fitness nutrition',
    videoId: '',
    ingredients: [
      { name: 'Oats (rolled)',               grams: 60  },
      { name: 'Curd / Dahi (full fat)',      grams: 100 },
      { name: 'Diesel NZ Whey Isolate',      grams: 30  },
      { name: 'Chia Seeds',                  grams: 10  },
      { name: 'Banana (ripe)',               grams: 80  },
      { name: 'Almonds (Badam)',             grams: 15  },
    ]
  },

  {
    name: 'Protein Smoothie',
    category: 'breakfast',
    servingSize: '1 glass',
    prepTime: '5 min',
    source: 'Post workout recovery',
    videoId: '',
    ingredients: [
      { name: 'Diesel NZ Whey Isolate',      grams: 30  },
      { name: 'Milk (cow, full fat)',        grams: 250 },
      { name: 'Banana (ripe)',               grams: 100 },
      { name: 'Peanut Butter (natural)',     grams: 20  },
      { name: 'Chia Seeds',                  grams: 10  },
    ]
  },

  {
    name: 'Quinoa Upma',
    category: 'breakfast',
    servingSize: '1 bowl',
    prepTime: '20 min',
    source: 'High protein upma alternative',
    videoId: 'rCfTnlYqFuY',
    ingredients: [
      { name: 'Quinoa (raw)',                grams: 60  },
      { name: 'Onion',                       grams: 60  },
      { name: 'Tomato',                      grams: 60  },
      { name: 'Peas (Matar, fresh)',         grams: 40  },
      { name: 'Carrot (Gajar)',              grams: 40  },
      { name: 'Mustard Oil',                 grams: 5   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Green Chilli',               grams: 5   },
      { name: 'Curry Leaves',               grams: 3   },
      { name: 'Salt',                        grams: 2   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Poha with Peanuts',
    category: 'breakfast',
    servingSize: '1 plate',
    prepTime: '15 min',
    source: 'Hebbars Kitchen classic poha',
    videoId: 'lWkCLGoQzaE',
    ingredients: [
      { name: 'Poha (Flattened Rice)',       grams: 80  },
      { name: 'Peanuts / Groundnuts',        grams: 30  },
      { name: 'Onion',                       grams: 60  },
      { name: 'Tomato',                      grams: 40  },
      { name: 'Green Chilli',               grams: 5   },
      { name: 'Curry Leaves',               grams: 3   },
      { name: 'Mustard Oil',                 grams: 5   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Salt',                        grams: 2   },
      { name: 'Coriander Leaves (Dhania)',   grams: 8   },
    ]
  },

  {
    name: 'Soya Oats Porridge',
    category: 'breakfast',
    servingSize: '1 bowl',
    prepTime: '10 min',
    source: 'Biki Singh high protein breakfast',
    videoId: '',
    ingredients: [
      { name: 'Oats (rolled)',               grams: 60  },
      { name: 'Soya Chunks',                grams: 20  },
      { name: 'Milk (cow, full fat)',        grams: 200 },
      { name: 'Banana (ripe)',               grams: 80  },
      { name: 'Peanut Butter (natural)',     grams: 15  },
      { name: 'Almonds (Badam)',             grams: 10  },
    ]
  },

  {
    name: 'Sprouts Chaat',
    category: 'breakfast',
    servingSize: '1 bowl',
    prepTime: '10 min + overnight sprouting',
    source: 'Tarla Dalal protein breakfast',
    videoId: 'tVXzaRBZWtY',
    ingredients: [
      { name: 'Whole Moong (Green Gram)',    grams: 60  },
      { name: 'Onion',                       grams: 40  },
      { name: 'Tomato',                      grams: 40  },
      { name: 'Cucumber (Kheera)',           grams: 50  },
      { name: 'Green Chilli',               grams: 5   },
      { name: 'Coriander Leaves (Dhania)',   grams: 8   },
      { name: 'Salt',                        grams: 2   },
    ]
  },

  // ══════════════════════════════════════════════
  // LUNCH
  // ══════════════════════════════════════════════

  {
    name: 'Dal Tadka',
    category: 'lunch',
    servingSize: '1 bowl',
    prepTime: '30 min',
    source: 'Varinder Ghuman staple',
    videoId: '_oyxCn2iSjU',
    ingredients: [
      { name: 'Toor Dal',                    grams: 60  },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 80  },
      { name: 'Garlic (Lehsun)',             grams: 10  },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Ghee',                        grams: 10  },
      { name: 'Cumin Seeds (Jeera)',         grams: 3   },
      { name: 'Turmeric Powder (Haldi)',     grams: 2   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Rajma Masala',
    category: 'lunch',
    servingSize: '1 bowl',
    prepTime: '45 min + overnight soak',
    source: 'Biki Singh meal 3',
    videoId: 'YHKGpHuNz3Y',
    ingredients: [
      { name: 'Rajma (Kidney Beans)',        grams: 80  },
      { name: 'Onion',                       grams: 100 },
      { name: 'Tomato',                      grams: 100 },
      { name: 'Garlic (Lehsun)',             grams: 10  },
      { name: 'Ginger (Adrak)',              grams: 8   },
      { name: 'Mustard Oil',                 grams: 10  },
      { name: 'Cumin Seeds (Jeera)',         grams: 3   },
      { name: 'Turmeric Powder (Haldi)',     grams: 2   },
      { name: 'Red Chilli Powder',           grams: 3   },
      { name: 'Garam Masala',               grams: 3   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Chana Masala',
    category: 'lunch',
    servingSize: '1 bowl',
    prepTime: '40 min',
    source: 'Biki Singh meal 2',
    videoId: 'Tsr2CIQEH9Y',
    ingredients: [
      { name: 'Kabuli Chana (Chickpeas)',    grams: 80  },
      { name: 'Onion',                       grams: 100 },
      { name: 'Tomato',                      grams: 100 },
      { name: 'Garlic (Lehsun)',             grams: 10  },
      { name: 'Ginger (Adrak)',              grams: 8   },
      { name: 'Sunflower Oil',              grams: 10  },
      { name: 'Cumin Seeds (Jeera)',         grams: 3   },
      { name: 'Turmeric Powder (Haldi)',     grams: 2   },
      { name: 'Red Chilli Powder',           grams: 3   },
      { name: 'Garam Masala',               grams: 3   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Palak Paneer',
    category: 'lunch',
    servingSize: '1 bowl',
    prepTime: '30 min',
    source: 'Tarla Dalal classic',
    videoId: 'vYGywZYHBOg',
    ingredients: [
      { name: 'Paneer (full fat)',           grams: 100 },
      { name: 'Spinach (Palak)',             grams: 150 },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 60  },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Ghee',                        grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
    ]
  },

  {
    name: 'Soya Chunk Masala',
    category: 'lunch',
    servingSize: '1 bowl',
    prepTime: '25 min',
    source: 'Hiralal Dhillan diet',
    videoId: 'yt0xZ3hBjDM',
    ingredients: [
      { name: 'Soya Chunks',                grams: 50  },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 80  },
      { name: 'Capsicum / Bell Pepper',      grams: 50  },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Sunflower Oil',              grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 2   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Dal Khichdi',
    category: 'lunch',
    servingSize: '1 bowl',
    prepTime: '25 min',
    source: 'Complete protein meal',
    videoId: 'b3pJOXbqACs',
    ingredients: [
      { name: 'Moong Dal (Yellow, split)',   grams: 50  },
      { name: 'Basmati Rice (raw)',          grams: 40  },
      { name: 'Ghee',                        grams: 5   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Carrot (Gajar)',              grams: 40  },
      { name: 'Peas (Matar, fresh)',         grams: 40  },
      { name: 'Salt',                        grams: 2   },
      { name: 'Coriander Leaves (Dhania)',   grams: 8   },
    ]
  },

  {
    name: 'Basmati Rice',
    category: 'lunch',
    servingSize: '1 katori cooked',
    prepTime: '15 min',
    source: 'Biki Singh with ghee',
    videoId: '',
    ingredients: [
      { name: 'Basmati Rice (raw)',          grams: 60  },
      { name: 'Ghee',                        grams: 5   },
      { name: 'Salt',                        grams: 1   },
    ]
  },

  {
    name: 'Whole Wheat Roti',
    category: 'lunch',
    servingSize: '2 rotis',
    prepTime: '15 min',
    source: 'Varinder Ghuman staple',
    videoId: '',
    ingredients: [
      { name: 'Whole Wheat Flour (Atta)',    grams: 60  },
      { name: 'Ghee',                        grams: 5   },
      { name: 'Salt',                        grams: 1   },
    ]
  },

  {
    name: 'Panchmel Dal',
    category: 'lunch',
    servingSize: '1 bowl',
    prepTime: '35 min',
    source: 'Complete amino acid dal mix',
    videoId: 'AYU-UGY8W0A',
    ingredients: [
      { name: 'Toor Dal',                    grams: 20  },
      { name: 'Moong Dal (Yellow, split)',   grams: 15  },
      { name: 'Masoor Dal (Red Lentil)',     grams: 15  },
      { name: 'Chana Dal',                   grams: 15  },
      { name: 'Urad Dal',                    grams: 15  },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 80  },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Ghee',                        grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 3   },
      { name: 'Turmeric Powder (Haldi)',     grams: 2   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
    ]
  },

  {
    name: 'Tofu Bhurji',
    category: 'lunch',
    servingSize: '1 plate',
    prepTime: '15 min',
    source: 'High protein paneer alternative',
    videoId: 'ZyNs3BLFMTA',
    ingredients: [
      { name: 'Tofu (extra firm)',           grams: 150 },
      { name: 'Onion',                       grams: 60  },
      { name: 'Tomato',                      grams: 80  },
      { name: 'Capsicum / Bell Pepper',      grams: 50  },
      { name: 'Sunflower Oil',              grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Methi Thepla',
    category: 'lunch',
    servingSize: '3 theplas',
    prepTime: '25 min',
    source: 'Hebbars Kitchen Gujarati staple',
    videoId: 'i_F5XLSKVSY',
    ingredients: [
      { name: 'Whole Wheat Flour (Atta)',    grams: 80  },
      { name: 'Fenugreek Leaves (Methi)',    grams: 40  },
      { name: 'Curd / Dahi (full fat)',      grams: 40  },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Green Chilli',               grams: 5   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Salt',                        grams: 2   },
      { name: 'Sunflower Oil',              grams: 5   },
    ]
  },

  // ══════════════════════════════════════════════
  // DINNER
  // ══════════════════════════════════════════════

  {
    name: 'Masoor Dal',
    category: 'dinner',
    servingSize: '1 bowl',
    prepTime: '20 min',
    source: 'Everyday Indian dinner',
    videoId: 'ZZIatXMFaQI',
    ingredients: [
      { name: 'Masoor Dal (Red Lentil)',     grams: 60  },
      { name: 'Onion',                       grams: 60  },
      { name: 'Tomato',                      grams: 60  },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Ghee',                        grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Salt',                        grams: 2   },
      { name: 'Coriander Leaves (Dhania)',   grams: 8   },
    ]
  },

  {
    name: 'Paneer Tikka',
    category: 'dinner',
    servingSize: '1 plate',
    prepTime: '30 min',
    source: 'High protein low carb dinner',
    videoId: 'KaFRuMPLYcM',
    ingredients: [
      { name: 'Paneer (full fat)',           grams: 150 },
      { name: 'Curd / Dahi (full fat)',      grams: 60  },
      { name: 'Capsicum / Bell Pepper',      grams: 60  },
      { name: 'Onion',                       grams: 60  },
      { name: 'Tomato',                      grams: 60  },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Garlic (Lehsun)',             grams: 5   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 3   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Sunflower Oil',              grams: 5   },
      { name: 'Salt',                        grams: 3   },
    ]
  },

  {
    name: 'Tofu Tikka Masala',
    category: 'dinner',
    servingSize: '1 bowl',
    prepTime: '30 min',
    source: 'Vegan high protein dinner',
    videoId: 'IQMcAlNqsHE',
    ingredients: [
      { name: 'Tofu (extra firm)',           grams: 150 },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 100 },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Sunflower Oil',              grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Rajma Rice Bowl',
    category: 'dinner',
    servingSize: '1 bowl',
    prepTime: '10 min if pre-cooked',
    source: 'Biki Singh complete meal',
    videoId: '',
    ingredients: [
      { name: 'Rajma (Kidney Beans)',        grams: 80  },
      { name: 'Basmati Rice (raw)',          grams: 60  },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 80  },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ghee',                        grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
    ]
  },

  {
    name: 'Kadai Paneer',
    category: 'dinner',
    servingSize: '1 bowl',
    prepTime: '30 min',
    source: 'Hebbars Kitchen restaurant style',
    videoId: 'SjFMdH-sZo4',
    ingredients: [
      { name: 'Paneer (full fat)',           grams: 150 },
      { name: 'Capsicum / Bell Pepper',      grams: 80  },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 100 },
      { name: 'Garlic (Lehsun)',             grams: 10  },
      { name: 'Ginger (Adrak)',              grams: 8   },
      { name: 'Sunflower Oil',              grams: 10  },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 3   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
      { name: 'Coriander Leaves (Dhania)',   grams: 10  },
    ]
  },

  {
    name: 'Chana Dal with Spinach',
    category: 'dinner',
    servingSize: '1 bowl',
    prepTime: '35 min',
    source: 'High fiber high protein dal',
    videoId: 'cRmPLCMjEjA',
    ingredients: [
      { name: 'Chana Dal',                   grams: 70  },
      { name: 'Spinach (Palak)',             grams: 100 },
      { name: 'Onion',                       grams: 60  },
      { name: 'Tomato',                      grams: 60  },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Ghee',                        grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Salt',                        grams: 3   },
    ]
  },

  {
    name: 'Matar Paneer',
    category: 'dinner',
    servingSize: '1 bowl',
    prepTime: '25 min',
    source: "Archana's Kitchen classic",
    videoId: 'W0fqnMPN_LI',
    ingredients: [
      { name: 'Paneer (full fat)',           grams: 100 },
      { name: 'Peas (Matar, fresh)',         grams: 80  },
      { name: 'Onion',                       grams: 80  },
      { name: 'Tomato',                      grams: 80  },
      { name: 'Garlic (Lehsun)',             grams: 8   },
      { name: 'Ginger (Adrak)',              grams: 5   },
      { name: 'Sunflower Oil',              grams: 8   },
      { name: 'Cumin Seeds (Jeera)',         grams: 2   },
      { name: 'Turmeric Powder (Haldi)',     grams: 1   },
      { name: 'Red Chilli Powder',           grams: 2   },
      { name: 'Garam Masala',               grams: 2   },
      { name: 'Salt',                        grams: 3   },
    ]
  },

  // ══════════════════════════════════════════════
  // SNACKS
  // ══════════════════════════════════════════════

  {
    name: 'Sattu Drink',
    category: 'snack',
    servingSize: '1 glass',
    prepTime: '3 min',
    source: 'Biki Singh between-meal snack',
    videoId: '',
    ingredients: [
      { name: 'Sattu (Roasted Chana Flour)', grams: 40 },
      { name: 'Jaggery (Gur)',              grams: 10  },
    ]
  },

  {
    name: 'Greek Yogurt with Nuts',
    category: 'snack',
    servingSize: '1 bowl',
    prepTime: '2 min',
    source: 'High protein snack',
    videoId: '',
    ingredients: [
      { name: 'Greek Yogurt (full fat)',     grams: 150 },
      { name: 'Almonds (Badam)',             grams: 15  },
      { name: 'Walnuts (Akhrot)',            grams: 10  },
      { name: 'Flaxseeds (Alsi)',            grams: 8   },
    ]
  },

  {
    name: 'Peanut Butter Banana',
    category: 'snack',
    servingSize: '1 serving',
    prepTime: '2 min',
    source: 'Pre-workout snack',
    videoId: '',
    ingredients: [
      { name: 'Peanut Butter (natural)',     grams: 30  },
      { name: 'Banana (ripe)',               grams: 100 },
    ]
  },

  {
    name: 'Sprouted Moong Salad',
    category: 'snack',
    servingSize: '1 bowl',
    prepTime: '5 min',
    source: "Archana's Kitchen protein salad",
    videoId: 'tVXzaRBZWtY',
    ingredients: [
      { name: 'Whole Moong (Green Gram)',    grams: 60  },
      { name: 'Onion',                       grams: 40  },
      { name: 'Tomato',                      grams: 40  },
      { name: 'Cucumber (Kheera)',           grams: 50  },
      { name: 'Green Chilli',               grams: 5   },
      { name: 'Coriander Leaves (Dhania)',   grams: 8   },
    ]
  },

  {
    name: 'Protein Shake',
    category: 'snack',
    servingSize: '1 glass',
    prepTime: '2 min',
    source: 'Post workout recovery',
    videoId: '',
    ingredients: [
      { name: 'Diesel NZ Whey Isolate',      grams: 30  },
      { name: 'Milk (cow, full fat)',        grams: 300 },
    ]
  },

  {
    name: 'Mixed Nuts and Dates',
    category: 'snack',
    servingSize: '1 handful',
    prepTime: '0 min',
    source: 'Varinder Ghuman snack',
    videoId: '',
    ingredients: [
      { name: 'Almonds (Badam)',             grams: 15  },
      { name: 'Cashews (Kaju)',              grams: 10  },
      { name: 'Pumpkin Seeds',              grams: 10  },
      { name: 'Dates (Khajoor, dry)',        grams: 20  },
    ]
  },

  {
    name: 'Roasted Chana',
    category: 'snack',
    servingSize: '1 handful (30g)',
    prepTime: '0 min',
    source: 'Biki Singh daily snack',
    videoId: '',
    ingredients: [
      { name: 'Chana (Bengal Gram whole)',   grams: 30  },
    ]
  },

  {
    name: 'Paneer Cubes',
    category: 'snack',
    servingSize: '1 serving (100g)',
    prepTime: '0 min',
    source: 'High protein zero carb snack',
    videoId: '',
    ingredients: [
      { name: 'Paneer (full fat)',           grams: 100 },
      { name: 'Salt',                        grams: 1   },
      { name: 'Red Chilli Powder',           grams: 1   },
    ]
  },

];

const recipes = rawRecipes.map(buildRecipe);

function getByCategory(category) {
  return recipes.filter(r => r.category === category);
}

function printRecipe(recipe) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(`${recipe.name.toUpperCase()}`);
  console.log(`Category: ${recipe.category} | Serving: ${recipe.servingSize} | Time: ${recipe.prepTime}`);
  console.log(`${'─'.repeat(60)}`);
  recipe.ingredients.forEach(item => {
    if (item.macros) {
      console.log(`  ${item.name.padEnd(32)} ${String(item.grams + 'g').padEnd(8)} P:${item.macros.protein}g C:${item.macros.carbs}g F:${item.macros.fat}g ${item.macros.calories}cal`);
    }
  });
  console.log(`${'─'.repeat(60)}`);
  const t = recipe.totalMacros;
  console.log(`TOTAL  P:${t.protein}g | C:${t.carbs}g | F:${t.fat}g | Fiber:${t.fiber}g | Cal:${t.calories}`);
}

function printCategory(category) {
  const list = getByCategory(category);
  console.log(`\n${'#'.repeat(60)}`);
  console.log(`${category.toUpperCase()} (${list.length} recipes)`);
  console.log(`${'#'.repeat(60)}`);
  list.forEach(printRecipe);
}

module.exports = { recipes, getByCategory, printRecipe, printCategory };

if (require.main === module) {
  console.log('FITDESI INDIAN VEGETARIAN RECIPES');
  console.log(`Total: ${recipes.length} recipes`);
  ['breakfast', 'lunch', 'dinner', 'snack'].forEach(cat => {
    console.log(`${cat}: ${getByCategory(cat).length} recipes`);
  });
  console.log('\nSUMMARY:');
  console.log('Name'.padEnd(30) + 'Cat'.padEnd(12) + 'P'.padEnd(8) + 'C'.padEnd(8) + 'F'.padEnd(8) + 'Cal');
  console.log('─'.repeat(68));
  recipes.forEach(r => {
    const t = r.totalMacros;
    console.log(
      r.name.padEnd(30) +
      r.category.padEnd(12) +
      (t.protein + 'g').padEnd(8) +
      (t.carbs   + 'g').padEnd(8) +
      (t.fat     + 'g').padEnd(8) +
      t.calories
    );
  });
}
